﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.Drawing;
using System.Net.Http;
using System.Net;
using System.Text.RegularExpressions;
using System.Text;
using System.Windows.Forms;
using System;
namespace TelegramSentimentAnalyzer
{
    public class MainForm : Form
    {
        // Конфигурация Yandex Cloud API
        private const string YandexFolderId = "b1g8frmmme38nkbegmp1";
        private const string YandexApiKey = "AQVN1lnyXzmFAjTEsxi-rdb77xoq1iBX7mTG63p_";
        private const string YandexAnalyzeUrl = "https://llm.api.cloud.yandex.net/foundationModels/v1/completion";

        // Элементы управления
        private TextBox txtComment;
        private Button btnAnalyze;
        private TextBox txtSentiment;
        private ListBox lstKeywords;
        private StatusStrip statusStrip;
        private ToolStripStatusLabel lblStatus;

        public MainForm()
        {
            SetupUI();
        }

        private void SetupUI()
        {
            // Настройка формы
            this.Text = "Анализатор комментариев Telegram";
            this.Size = new Size(650, 500);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Font = new Font("Segoe UI", 10);

            // Элементы управления
            var lblComment = new Label
            {
                Text = "Комментарий для анализа:",
                Location = new Point(20, 20),
                AutoSize = true
            };

            txtComment = new TextBox
            {
                Multiline = true,
                ScrollBars = ScrollBars.Vertical,
                Location = new Point(20, 50),
                Size = new Size(600, 150)
            };

            btnAnalyze = new Button
            {
                Text = "Анализировать комментарий",
                Location = new Point(20, 210),
                Size = new Size(200, 40),
                BackColor = Color.LightSkyBlue
            };
            btnAnalyze.Click += BtnAnalyze_Click;

            var lblSentimentTitle = new Label
            {
                Text = "Тональность:",
                Location = new Point(20, 270),
                AutoSize = true
            };

            txtSentiment = new TextBox
            {
                Location = new Point(120, 265),
                Size = new Size(150, 30),
                ReadOnly = true
            };

            var lblKeywords = new Label
            {
                Text = "Ключевые слова:",
                Location = new Point(20, 310),
                AutoSize = true
            };

            lstKeywords = new ListBox
            {
                Location = new Point(20, 340),
                Size = new Size(300, 100)
            };

            statusStrip = new StatusStrip();
            statusStrip.Dock = DockStyle.Bottom;
            lblStatus = new ToolStripStatusLabel
            {
                Text = "Готов к анализу",
                AutoSize = true
            };
            statusStrip.Items.Add(lblStatus);

            // Добавление элементов на форму
            this.Controls.Add(lblComment);
            this.Controls.Add(txtComment);
            this.Controls.Add(btnAnalyze);
            this.Controls.Add(lblSentimentTitle);
            this.Controls.Add(txtSentiment);
            this.Controls.Add(lblKeywords);
            this.Controls.Add(lstKeywords);
            this.Controls.Add(statusStrip);
        }

        private async void BtnAnalyze_Click(object sender, EventArgs e)
        {
            string comment = txtComment.Text.Trim();

            if (string.IsNullOrEmpty(comment))
            {
                MessageBox.Show("Пожалуйста, введите комментарий для анализа",
                    "Ошибка ввода", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                lblStatus.Text = "Анализ комментария...";
                btnAnalyze.Enabled = false;
                this.Cursor = Cursors.WaitCursor;
                // Формирование запроса к YandexGPT API
                var requestData = new
                {
                    modelUri = $"gpt://{YandexFolderId}/yandexgpt",
                    completionOptions = new
                    {
                        stream = false,
                        temperature = 0.3,
                        maxTokens = 300 // Увеличен лимит токенов
                    },
                    messages = new[]
                    {
                        new
                        {
                            role = "system",
                            text = "Ты - аналитик настроений в Telegram. Определи тональность комментария (позитивный, негативный, нейтральный) и выдели 3-5 ключевых тем. Ответ предоставь ТОЛЬКО в формате JSON: {\"sentiment\": \"\", \"keywords\": []} Без дополнительного текста! Ответ должен быть в одну строку без форматирования."
                        },
                        new
                        {
                            role = "user",
                            text = $"Комментарий: \"{comment}\""
                        }
                    }
                };

                // Отправка запроса
                using (HttpClient client = new HttpClient())
                {
                    client.Timeout = TimeSpan.FromSeconds(60);
                    client.DefaultRequestHeaders.Add("Authorization", $"Api-Key {YandexApiKey}");

                    var jsonContent = new StringContent(
                        JsonConvert.SerializeObject(requestData),
                        Encoding.UTF8,
                        "application/json"
                    );

                    var response = await client.PostAsync(YandexAnalyzeUrl, jsonContent);

                    // Обработка ответа
                    if (response.IsSuccessStatusCode)
                    {
                        string jsonResponse = await response.Content.ReadAsStringAsync();
                        dynamic result = JsonConvert.DeserializeObject(jsonResponse);

                        string analysisResult = result.result.alternatives[0].message.text;
                        ProcessAnalysisResult(analysisResult);
                    }
                    else
                    {
                        string errorContent = await response.Content.ReadAsStringAsync();
                        string errorMessage = $"Ошибка API: {response.StatusCode}";

                        if (response.StatusCode == (HttpStatusCode)429)
                        {
                            errorMessage += "\nСлишком много запросов. Пожалуйста, подождите 1 минуту.";
                        }

                        throw new Exception(errorMessage + $"\n{errorContent}");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка анализа:\n{ex.Message}", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                btnAnalyze.Enabled = true;
                this.Cursor = Cursors.Default;
                lblStatus.Text = "Анализ завершен";
            }
        }

        private void ProcessAnalysisResult(string jsonResult)
        {
            try
            {
                // 1. Попытка найти валидный JSON в ответе
                string cleanJson = ExtractJsonFromResponse(jsonResult);

                // 2. Десериализация JSON
                var result = JsonConvert.DeserializeObject<AnalysisResult>(cleanJson);

                // 3. Обновление интерфейса
                UpdateUIWithResults(result.sentiment, result.keywords);
            }
            catch (Exception ex)
            {
                // 4. Резервный метод извлечения данных
                try
                {
                    string sentiment = ExtractSentiment(jsonResult);
                    List<string> keywords = ExtractKeywords(jsonResult);
                    UpdateUIWithResults(sentiment, keywords);
                }
                catch (Exception fallbackEx)
                {
                    MessageBox.Show($"Ошибка обработки ответа ИИ:\n{fallbackEx.Message}\n\nОтвет API:\n{jsonResult}",
                        "Ошибка формата", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            }

            private string ExtractJsonFromResponse(string response)
            {
                // Удаляем все символы до первой '{'
                int startIndex = response.IndexOf('{');
                if (startIndex < 0) throw new Exception("JSON start not found");
                response = response.Substring(startIndex);

                // Удаляем все символы после последней '}'
                int endIndex = response.LastIndexOf('}');
                if (endIndex < 0) throw new Exception("JSON end not found");
                response = response.Substring(0, endIndex + 1);

                // Удаление escape-символов
                response = response.Replace("\\\"", "\"")
                                   .Replace("\\n", "")
                                   .Replace("\\r", "")
                                   .Replace("\\t", "");

                return response;
            }

            private string ExtractSentiment(string text)
            {
                // Регулярное выражение для поиска тональности
                var match = Regex.Match(text, @"""sentiment""\s*:\s*""([^""]*)""", RegexOptions.IgnoreCase);
                if (match.Success && match.Groups.Count > 1)
                {
                    return match.Groups[1].Value;
                }
                return "не определено";
            }

            private List<string> ExtractKeywords(string text)
            {
                var keywords = new List<string>();

                // Поиск массива keywords
                var match = Regex.Match(text, @"""keywords""\s*:\s*\[([^\]]*)\]", RegexOptions.IgnoreCase);
                if (match.Success && match.Groups.Count > 1)
                {
                    string keywordsString = match.Groups[1].Value;

                    // Извлечение отдельных ключевых слов
                    var wordMatches = Regex.Matches(keywordsString, @"""([^""]*)""");
                    foreach (Match wordMatch in wordMatches)
                    {
                        if (wordMatch.Success && wordMatch.Groups.Count > 1)
                        {
                            keywords.Add(wordMatch.Groups[1].Value);
                        }
                    }
                }
                return keywords;
            }

            private void UpdateUIWithResults(string sentiment, List<string> keywords)
            {
                // Обновление интерфейса
                txtSentiment.Text = sentiment;
                lstKeywords.Items.Clear();

                foreach (var keyword in keywords)
                {
                    lstKeywords.Items.Add(keyword);
                }

                // Визуальное выделение тональности
                if (sentiment.Contains("позитив") || sentiment.Contains("positive"))
                {
                    txtSentiment.BackColor = Color.LightGreen;
                }
                else if (sentiment.Contains("негатив") || sentiment.Contains("negative"))
                {
                    txtSentiment.BackColor = Color.LightCoral;
                }
                else
                {
                    txtSentiment.BackColor = Color.LightGray;
                }
            }

        // Класс для десериализации JSON
        private class AnalysisResult
        {
            public string sentiment { get; set; }
            public List<string> keywords { get; set; }
        }
    }
static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MainForm());
        }
    }
}
